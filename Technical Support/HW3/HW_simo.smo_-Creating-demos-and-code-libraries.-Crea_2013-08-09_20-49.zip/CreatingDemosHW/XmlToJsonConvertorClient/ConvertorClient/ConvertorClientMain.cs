﻿using System;
using System.IO;
using System.Xml;
using XmlJsonConvertor;

namespace ConvertorClient
{
    /// <summary>
    /// This is a project that using the XmlJsonConvertor assembly reads file with a Json string and generates a XmlDocument from it and vise versa
    /// </summary>
    class ConvertorClientMain
    {
        static void Main(string[] args)
        {
            // Use the XmlJsonConvertor library to create XML file from Json file
            string jsonInputPath = Settings.Default.JsonInputPath;
            string xmlOutputPath = Settings.Default.XmlOutputPath;
            GenerateXmlFileFromJson(jsonInputPath, xmlOutputPath);

            // Use the XmlJsonConvertor library to create Json file from XML file
            string xmlInputPath = Settings.Default.XmlInputPath;
            string jsonOutputPath = Settings.Default.JsonOutputPath;
            GenerateJsonFileFromXml(xmlInputPath, jsonOutputPath);
        }

        /// <summary>
        /// This method reads a Xml input file and generates a Json output text file
        /// </summary>
        /// <param name="xmlInputPath">The path to the Xml input file</param>
        /// <param name="jsonOutputPath">The path to the Json output text file</param>
        private static void GenerateJsonFileFromXml(string xmlInputPath, string jsonOutputPath)
        {
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load(xmlInputPath);

            string jsonOutputString = Convertor.ToJson(xmlDocument);
            jsonOutputString = jsonOutputString.Replace("},", "},\r\n");

            using (StreamWriter sw = new StreamWriter(jsonOutputPath))
            {
                sw.Write(jsonOutputString);
            }
        }

        /// <summary>
        /// This method reads a Json input text file and generates a Xml output file
        /// </summary>
        /// <param name="jsonInputPath">The path to the Json input text file</param>
        /// <param name="xmlOutputPath">The path to the Xml output file</param>
        private static void GenerateXmlFileFromJson(string jsonInputPath, string xmlOutputPath)
        {
            using (StreamReader sr = new StreamReader(jsonInputPath))
            {
                string jsonInputString = sr.ReadToEnd();
                XmlDocument resultXml = Convertor.ToXML(jsonInputString);

                resultXml.Save(xmlOutputPath);
            }
        }
    }
}
