﻿using Newtonsoft.Json;
using System;
using System.Xml;

namespace XmlJsonConvertor
{
    /// <summary>
    /// This class contains methods for conversion a XmlDocument into Json string and vice versa
    /// </summary>
    public class Convertor
    {
        /// <summary>
        /// This method gets a XmlDocument and returns the corresponding Json string
        /// </summary>
        /// <param name="xmlDocument">The XmlDocument that has to be converted</param>
        /// <returns>The Json string that corresponds to the XmlDocument</returns>
        public static string ToJson(XmlDocument xmlDocument)
        {
            if (xmlDocument == null)
            {
                throw new ArgumentNullException("The XML document cannot be null");
            }

            return JsonConvert.SerializeXmlNode(xmlDocument);
        }

        /// <summary>
        /// This method gets a Json string and returns the corresponding XmlDocument
        /// </summary>
        /// <param name="jsonString">The Json string that has to be converted</param>
        /// <returns>The XmlDocument that corresponds to the Json string</returns>
        public static XmlDocument ToXML(string jsonString)
        {
            if (jsonString == null)
            {
                throw new ArgumentNullException("The Json string cannot be null");
            }

            return (XmlDocument)JsonConvert.DeserializeXmlNode(jsonString);
        }
    }
}
