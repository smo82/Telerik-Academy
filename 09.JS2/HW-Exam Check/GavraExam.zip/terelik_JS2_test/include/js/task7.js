var gallery = controls.getImageGallery("#image-gallery-holder");

gallery.addImage("JS Ninja","../images/ninja.png");
gallery.addImage("JS Ninja","../images/ninja.png");
gallery.addImage("JS Ninja","../images/ninja.png");

var ninjasAlbum = gallery.addAlbum("Ninjas");

ninjasAlbum.addImage("JS Ninja 2","images/js-ninja.png");
ninjasAlbum.addImage("JS Ninja 2","images/js-ninja.png");
ninjasAlbum.addImage("JS Ninja 2","images/js-ninja.png");