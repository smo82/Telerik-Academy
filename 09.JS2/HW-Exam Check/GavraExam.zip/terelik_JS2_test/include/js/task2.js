var ninjasAlbum = gallery.addAlbum("Ninjas");

gallery.addImage("JS Ninja","../images/js-ninja.png");
gallery.addImage("JS Ninja","../images/js-ninja.png");
gallery.addImage("JS Ninja","../images/js-ninja.png");

ninjasAlbum.addImage("JS Ninja 2","../images/js-ninja.png");
ninjasAlbum.addImage("JS Ninja 2","../images/js-ninja.png");
ninjasAlbum.addImage("JS Ninja 2","../images/js-ninja.png");

var ninjasAlbum = ninjasAlbum.addAlbum("Kids Ninjas");

kidsAlbum.addImage("Kid Ninja","../images/js-ninja.png");
kidsAlbum.addImage("Kid Ninja","../images/js-ninja.png");