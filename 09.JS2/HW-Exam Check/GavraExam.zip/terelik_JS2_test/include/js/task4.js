var imageGalleryData = [/*image gallert data*/];
imageGalleryRepository.save ("ninjas-gallery",imageGalleryData);
var galleryData = imageGalleryRepository.load(ninjas-gallery);