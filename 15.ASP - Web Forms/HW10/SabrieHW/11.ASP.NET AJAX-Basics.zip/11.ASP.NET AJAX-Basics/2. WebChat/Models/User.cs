﻿using System;
namespace _2.WebChat.Models
{
    using System;

    public class User
    {
        public int Id { get; set; }

        public string Username { get; set; }
    }
}
