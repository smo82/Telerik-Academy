﻿namespace ListView_DataPager_Demo
{
	public class Product
	{
		public string Name { get; set; }
		public decimal Price { get; set; }
	}
}
