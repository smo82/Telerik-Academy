This is a nearly full version of Modernizr 2.6.2 that I downloaded from
http://modernizr.com/download.   It includes everying  except added css
queries and the  community  add-ons,  including yepnope support so that
Modernizr.load will work.
