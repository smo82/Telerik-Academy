﻿var carsModel = [];

var carDataSource = new kendo.data.DataSource({
    data: carsModel,
});