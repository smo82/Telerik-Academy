﻿$(document).ready(function () {
    kendo.bind($('#car-add-view'), carViewModel);
});