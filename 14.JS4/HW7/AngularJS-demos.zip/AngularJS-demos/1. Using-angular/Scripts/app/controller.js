﻿function MainController($scope) {
	$scope.people =
	[{ name: "Doncho", "age": 12 },
	{ name: "Joro", "age": 12 },
	{ name: "Niki", "age": 12 },
	{ name: "Nakov", "age": 12 },
	{ name: "Ivo", "age": 12 }];
}