﻿[{
	"title": "JavaScript Frameworks Course in Telerik Academy",
	"content": "the JavaScript Frameworks Course in Telerik Academy is just about to start. Don't miss it, you will be sorry!"
}, {
	"title": "Windows 8 store applications with HTML",
	"content": "Telerik Academy is about to launch the new course for Windows 8 Store applications this summer. The course will cover the basics for creating "
}]